-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2015 at 07:03 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_police_weapon_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE IF NOT EXISTS `tbl_district` (
`id` int(11) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`id`, `name`) VALUES
(1, 'PHƯỜNG 1'),
(2, 'PHƯỜNG 2'),
(3, 'PHƯỜNG 3'),
(4, 'PHƯỜNG 4'),
(5, 'PHƯỜNG 5'),
(6, 'XÃ TÂN NGÃI'),
(7, 'PHƯỜNG 8'),
(8, 'PHƯỜNG 9'),
(9, 'XÃ TÂN HỘI');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_license`
--

CREATE TABLE IF NOT EXISTS `tbl_license` (
`id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `id_organization` int(11) NOT NULL,
  `id_weapon` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '1',
  `date` date NOT NULL,
  `limit_date` date NOT NULL,
  `employee` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_license`
--

INSERT INTO `tbl_license` (`id`, `type`, `id_organization`, `id_weapon`, `count`, `date`, `limit_date`, `employee`) VALUES
(1, 1, 1, 1, 1, '2015-03-01', '2015-03-30', 'Lê Văn Cẩn'),
(3, 3, 2, 1, 1, '2015-02-12', '2015-03-12', 'Lê Văn Cẩn'),
(25, 1, 6, 1, 1, '2015-03-04', '2015-03-04', 'BÙI THANH TUẤN'),
(30, 2, 7, 1, 1, '2015-03-04', '2015-03-04', ''),
(31, 1, 2, 5, 5, '2015-03-05', '2015-03-05', '8'),
(33, 2, 1, 5, 1, '2015-03-05', '2015-03-05', 'Bùi Thanh Tuấn'),
(34, 2, 1, 6, 1, '2015-03-05', '2015-03-05', 'Bùi Thanh Tuấn'),
(35, 2, 1, 9, 1, '2015-03-05', '2015-03-05', 'Bùi Thanh Tuấn'),
(38, 3, 1, 5, 1, '2015-03-07', '2015-03-07', 'Bùi Thanh Tuấn');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_license_buy`
--

CREATE TABLE IF NOT EXISTS `tbl_license_buy` (
`id` int(11) NOT NULL,
  `id_license` int(11) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(120) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `card_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `card_where` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `card_date` date NOT NULL,
  `suggest_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_license_buy`
--

INSERT INTO `tbl_license_buy` (`id`, `id_license`, `name`, `job`, `card_id`, `card_where`, `card_date`, `suggest_by`, `address`) VALUES
(1, 1, 'Nguyễn Văn A', 'Trung úy', '340995290', 'Đồng Tháp', '2011-12-01', 'Trần Văn B', 'Hồng Ngự Đồng Tháp'),
(8, 25, 'LÊ VĂN CẨN', 'THIẾU ÚY', '212323434', 'CÀ MAU', '2015-03-04', 'LÊ CÔNG TOÀN', ''),
(13, 31, '1', '2', '3', '4', '2015-03-05', '7', '6');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_license_check`
--

CREATE TABLE IF NOT EXISTS `tbl_license_check` (
`id` int(11) NOT NULL,
  `id_license` int(11) NOT NULL,
  `quality` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `employee_check` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_check` date NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_license_check`
--

INSERT INTO `tbl_license_check` (`id`, `id_license`, `quality`, `employee_check`, `date_check`, `note`) VALUES
(1, 38, 'Tốt', 'Lề Văn Cẩn', '2015-03-07', 'Không có gì');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_license_register`
--

CREATE TABLE IF NOT EXISTS `tbl_license_register` (
`id` int(11) NOT NULL,
  `id_license` int(11) NOT NULL,
  `quality` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `purpose` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_declare` date NOT NULL,
  `employee_declared` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_license_register`
--

INSERT INTO `tbl_license_register` (`id`, `id_license`, `quality`, `purpose`, `date_declare`, `employee_declared`) VALUES
(1, 33, 'Tốt', 'Bảo vệ cổng', '2015-03-05', 'Lê Văn Cẩn'),
(2, 34, 'Tốt', 'Bảo vệ cổng', '2015-03-05', 'Nguyễn Thanh Bảo'),
(3, 35, 'Trung Bình', 'Bảo vệ cầu thang', '2015-03-01', 'Lê Công Toàn');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_organization`
--

CREATE TABLE IF NOT EXISTS `tbl_organization` (
`id` int(11) NOT NULL,
  `id_district` int(11) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_organization`
--

INSERT INTO `tbl_organization` (`id`, `id_district`, `name`, `phone`, `email`, `address`) VALUES
(1, 1, 'P11', '0703 111 222', 'vl1@gmail.com', '123, Lý Thái Tổ, P1 TP Vĩnh Long'),
(2, 1, 'P12', '1', '2', '3'),
(6, 2, 'P21', '1', '2', '3'),
(7, 2, 'P21', '1', '2', '3'),
(8, 1, 'P13', '1', '2', '3'),
(9, 1, 'P14', '1', '2', '3'),
(10, 3, 'P31', '1', '2', '3'),
(11, 3, 'P32', '1', '2', '3'),
(12, 3, 'P33', '1', '2', '3'),
(13, 4, 'P41', '1', '2', '3'),
(14, 4, 'P42', '1', '2', '3'),
(15, 4, 'P43', '1', '2', '3'),
(16, 5, 'P51', '1', '2', '3'),
(17, 5, 'P52', '1', '2', '3'),
(18, 6, 'TN1', '1', '2', '3'),
(19, 6, 'TN2', '1', '2', '3'),
(20, 7, 'P81', '1', '2', '3'),
(21, 7, 'P82', '1', '2', '3'),
(22, 7, 'P83', '1', '2', '3'),
(23, 8, 'P91', '1', '2', '3'),
(24, 8, 'P92', '1', '2', '3'),
(25, 9, 'TH1', '1', '2', '3'),
(26, 9, 'TH2', '1', '2', '3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_type_license`
--

CREATE TABLE IF NOT EXISTS `tbl_type_license` (
`id` int(11) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_type_license`
--

INSERT INTO `tbl_type_license` (`id`, `name`) VALUES
(1, 'Đăng kí mua'),
(2, 'Đăng kí sử dụng'),
(3, 'Gia hạn');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_type_weapon`
--

CREATE TABLE IF NOT EXISTS `tbl_type_weapon` (
`id` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_type_weapon`
--

INSERT INTO `tbl_type_weapon` (`id`, `name`) VALUES
(1, 'Vũ khí thô sơ'),
(2, 'Vật liệu nổ'),
(3, 'Công cụ hỗ trợ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_weapon`
--

CREATE TABLE IF NOT EXISTS `tbl_weapon` (
`id` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `name` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `number` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `made_in` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(11) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `where_num` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `native` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `doc` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_weapon`
--

INSERT INTO `tbl_weapon` (`id`, `id_type`, `name`, `number`, `made_in`, `year`, `size`, `where_num`, `native`, `doc`, `note`) VALUES
(1, 1, 'VK1', '1', '2', '3', '4', '5', '6', '7', '8'),
(3, 1, 'VK2', '1', '2', '3', '4', '5', '6', '7', '8'),
(4, 2, 'VL1', '1', '2', '3', '4', '5', '6', '7', '8'),
(5, 3, 'HT1', '1', '2', '3', '4', '5', '6', '7', '8'),
(6, 3, 'HT2', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'),
(7, 2, 'VL2', '1', '2', '3', '4', '5', '6', '7', '8'),
(8, 1, 'VK3', '1', '2', '3', '4', '5', '6', '7', '8'),
(9, 3, 'HT3', '1', '2', '3', '4', '5', '6', '7', '8'),
(10, 2, 'VL3', '1', '2', '3', '4', '5', '6', '7', '8'),
(11, 1, 'VK4', '1', '2', '3', '4', '5', '6', '8', '9'),
(12, 1, 'VK5', '1', '2', '3', '4', '5', '6', '8', '8'),
(13, 3, 'HT4', '1', '2', '3', '4', '5', '6', '7', '8'),
(14, 3, 'HT5', '1', '2', '3', '4', '5', '6', '7', '8'),
(15, 2, 'VL4', '1', '2', '3', '4', '5', '6', '7', '8'),
(16, 2, 'VL5', '1', '2', '3', '4', '5', '6', '7', '8'),
(17, 1, 'VK6', '1', '2', '3', '4', '5', '6', '7', '8'),
(18, 2, 'VL6', '1', '2', '3', '4', '5', '6', '7', '8');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_license`
--
ALTER TABLE `tbl_license`
 ADD PRIMARY KEY (`id`), ADD KEY `id_organization` (`id_organization`), ADD KEY `type` (`type`);

--
-- Indexes for table `tbl_license_buy`
--
ALTER TABLE `tbl_license_buy`
 ADD PRIMARY KEY (`id`), ADD KEY `id_license` (`id_license`);

--
-- Indexes for table `tbl_license_check`
--
ALTER TABLE `tbl_license_check`
 ADD PRIMARY KEY (`id`), ADD KEY `id_license` (`id_license`);

--
-- Indexes for table `tbl_license_register`
--
ALTER TABLE `tbl_license_register`
 ADD PRIMARY KEY (`id`), ADD KEY `id_license` (`id_license`);

--
-- Indexes for table `tbl_organization`
--
ALTER TABLE `tbl_organization`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_type_license`
--
ALTER TABLE `tbl_type_license`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_type_weapon`
--
ALTER TABLE `tbl_type_weapon`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_weapon`
--
ALTER TABLE `tbl_weapon`
 ADD PRIMARY KEY (`id`), ADD KEY `id_type` (`id_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_license`
--
ALTER TABLE `tbl_license`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `tbl_license_buy`
--
ALTER TABLE `tbl_license_buy`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_license_check`
--
ALTER TABLE `tbl_license_check`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_license_register`
--
ALTER TABLE `tbl_license_register`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_organization`
--
ALTER TABLE `tbl_organization`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `tbl_type_license`
--
ALTER TABLE `tbl_type_license`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_type_weapon`
--
ALTER TABLE `tbl_type_weapon`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_weapon`
--
ALTER TABLE `tbl_weapon`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_license`
--
ALTER TABLE `tbl_license`
ADD CONSTRAINT `tbl_license_ibfk_1` FOREIGN KEY (`id_organization`) REFERENCES `tbl_organization` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `tbl_license_ibfk_3` FOREIGN KEY (`type`) REFERENCES `tbl_type_license` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_license_buy`
--
ALTER TABLE `tbl_license_buy`
ADD CONSTRAINT `tbl_license_buy_ibfk_1` FOREIGN KEY (`id_license`) REFERENCES `tbl_license` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_license_check`
--
ALTER TABLE `tbl_license_check`
ADD CONSTRAINT `tbl_license_check_ibfk_1` FOREIGN KEY (`id_license`) REFERENCES `tbl_license` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_license_register`
--
ALTER TABLE `tbl_license_register`
ADD CONSTRAINT `tbl_license_register_ibfk_1` FOREIGN KEY (`id_license`) REFERENCES `tbl_license` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_weapon`
--
ALTER TABLE `tbl_weapon`
ADD CONSTRAINT `tbl_weapon_ibfk_1` FOREIGN KEY (`id_type`) REFERENCES `tbl_type_weapon` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
